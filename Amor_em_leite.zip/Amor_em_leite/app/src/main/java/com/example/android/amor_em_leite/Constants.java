package com.example.android.amor_em_leite;

/**
 * Created by HP on 30/09/2018.
 */

public class Constants {

    //Data URL
    public static final String DATA_URL_LOGIN = "http://192.168.1.42:8080/login/logar.php";

    //JSON TAGS
    public static final String TAG_IMAGE_URL = "image";
    public static final String TAG_NAME = "name";
    public static final String TAG_PUBLISHER = "publisher";
}
