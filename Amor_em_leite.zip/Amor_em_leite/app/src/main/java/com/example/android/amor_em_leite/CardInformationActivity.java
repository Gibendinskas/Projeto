package com.example.android.amor_em_leite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.TextView;

public class CardInformationActivity extends AppCompatActivity {

    int position;
    TextView textViewTitle, textViewContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_information);
        textViewTitle = findViewById(R.id.title_text);
        textViewContent = findViewById(R.id.content_text);

        if(getIntent().hasExtra("position")){

            position = getIntent().getIntExtra("position",0);

            switch (position) {
                case 0:
                    textViewTitle.setText("Como é feita a doação do leite materno?");
                    textViewContent.setText("Após o cadastro, a coleta pode ser feita no próprio banco de leite ou em casa -- dependendo do caso e da cidade, alguém buscará o leite uma vez por semana. \n" +
                            "\n" +
                            "São necessários alguns cuidados especiais durante a ordenha, como: \n" +
                            "\n" +
                            "Lavar as mãos e os antebraços com água e sabão, até os cotovelos, manter as unhas limpas;\n" +
                            "\n" +
                            "Desprezar os primeiros jatos de leite (cerca de 1 ml);\n" +
                            "\n" +
                            "Usar recipiente esterilizado, de boca larga, para recolher o leite;\n" +
                            "\n" +
                            "Guardar o leite coletado imediatamente no congelador;\n" +
                            "\n" +
                            "Não encher demais o recipiente;\n" +
                            "\n" +
                            "Também pode ser interessante usar uma máscara ou uma fralda de pano no rosto para reduzir ainda mais os riscos de contaminação do leite.");
                    break;
                case 1:
                    textViewTitle.setText("Se eu doar leite materno, vai faltar para meu filho?");
                    textViewContent.setText("Nao. O que ocorre é justamente o contrário. O organismo produz o leite na medida em que ele é demandado. Ou seja, quanto mais a mulher amamenta ou tira o leite, mais ela o produz. Esse é o funcionamento normal do organismo: assim que a mama é esvaziada, o corpo recebe um sinal para preparar mais. Portanto, se você amamentar e doar leite, estará estimulando ainda mais o seu organismo nesse sentido.");
                    break;
                case 2:
                    textViewTitle.setText("O que é um Banco de Leite Humano?");
                    textViewContent.setText("Os Bancos de Leite Humano (BLH) são iniciativas públicas vinculadas a hospitais infantis e maternidades, responsáveis por promover o aleitamento materno e executar as atividades de coleta, controle de qualidade, pasteurização e distribuição do leite pasteurizado. Em todo o Brasil, são 215 unidades espalhadas pelas cinco regiões do país, todas seguindo os mesmos procedimentos e normas estabelecidas pela Agência Nacional de Vigilância Sanitária (Anvisa). Os bancos recebem as doações – a coleta pode ser feita lá mesmo ou na casa da doadora – e sempre contam com médicos disponíveis para orientar as lactantes caso seja necessário. Em seguida, o volume é encaminhado para aqueles que precisam.");
                    break;

                case 3:
                    textViewTitle.setText("Como é o tratamento no Banco de Leite?");
                    textViewContent.setText("O leite doado passa por um processo de pasteurização, que é obrigatório no Brasil para todo o leite produzido no país. Esse procedimento foi criado em 1864 por Louis Pasteur, químico francês. A pasteurização é um procedimento que retarda a proliferação de bactérias nos alimentos (geralmente líquidos) por meio do aquecimento do item a uma determinada temperatura seguido pelo seu resfriamento. \n " +
                    "\n" +
                    "1) Degelo: O leite é degelado em banho maria, em uma temperatura de 45ºC, de 10 a 15 minutos. Em seguida passa por uma cadeia fria (gelocks) para manter a temperatura. \n" +
                    "\n" +
                    "2) Teste de Acidez: Coloca-se um produto – Fenolftaleína – em amostras de leite coletadas, e de acordo com a cor que o leite apresentar, é identificado o nível de acidez. \n"+
                    "\n" +
                    "3) Uniformização: A uma temperatura de 62,5ºC, as tampas dos vidros de leite devem ser giradas a ¾ de volta e os frascos devem ser agitados a cada 5 minutos, totalizando 45 minutos. Nesse processo as bactérias grudadas nas moléculas do leite e os gases liberados por essas bactérias vão embora. \n" +
                    "\n" +
                    "4) Calorias do Leite: É realizado um exame para avaliar a caloria desse leite. As amostras coletadas em capilar, são centrifugados em um crematócrito, que realiza uma leitura do valor energético do leite. \n" +
                    "\n" +
                    "5) Exame Microbiológico: Após o processo de aquecimento, o leite é resfriado para uma temperatura de -5ºC e mantido por 15 minutos até chegar em uma temperatura de 7ºC. Amostras coletadas são levadas para o laboratório para garantir que depois do processo de pasteurização, não houve nenhuma contaminação nesse leite.");
                    break;

                case 4  :
                    textViewTitle.setText("Qual a importância do leite materno na vida de um bebê?");
                    textViewContent.setText("As mães dos bebês prematuros produzem leite adequado às necessidades do filho na faixa de idade. Se ela permanece no hospital no período de recuperação, também adquire anticorpos para as bactérias circulantes na unidade e passará, via leite, ao filho. O líquido funcionará como vacina. Prematuros alimentados com leite materno têm menos infecção hospitalar e doenças como meningite, além de crescer mais rápido e ter alta precoce. No leite, há substâncias que ajudam a amadurecer os órgãos e os sistemas da criança. Para os bebês sem estrutura, o leite é via equipamentos. Vantagens:\n" +
                            "\n"+ "Melhor desempenho neurocomportamental\n" +
                            "Proteção contra o desenvolvimento da retinopatia da prematuridade\n" +
                            "Melhor desempenho cognitivo\n" +
                            "Relacionado a um menor índice de reinternação hospitalar\n" +
                            "Maior proteção antioxidante\n" +
                            "Menor risco de enterocolite, sepse e meningite\n" +
                            "Passagem de anticorpos maternos contra microorganismos da UTI neonatal\n" +
                            "Protege de alergias em prematuros com histórico familiar de atopia\n" +
                            "Maior coordenação de saucção/deglutição\n" +
                            "Aumento médio do peso em 18,8 gramas por dia");
                    break;
                case 5:
                    textViewTitle.setText(" Há restrições para quem pode doar leite?");
                    textViewContent.setText("Os bancos de leite fazem um cadastramento cuidadoso das doadoras justamente para avaliar se há alguma restrição. Ou seja, não adianta levar o leite ordenhado direto para o banco, sem passar pelo cadastro prévio. \n" +
                            "Em termos gerais, é preciso que o próprio filho da nutriz (a mulher que fornece o leite) esteja recebendo leite materno, a não ser em caso de força maior. \n" +
                            "Muitas vezes, mulheres que têm prematuros mantêm a ordenha no hospital para estimular a produção de leite, mesmo que o bebê ainda não possa mamar. Esse leite então é armazenado pelos bancos de leite.\n" +
                            "Os principais requisitos para doar são: \n" +
                            "\n" +
                            "-Apresentar exames do pré ou do pós-natal comprovando estar bem de saúde\n" +
                            "\n" +
                            "-Não fumar\n" +
                            "\n" +
                            "-Não tomar medicamentos incompatíveis com a amamentação\n" +
                            "\n" +
                            "-Não usar álcool ou drogas ilícitas");
                    break;
                case 6:
                    textViewTitle.setText("Tenho leite demais. Posso doar?");
                    textViewContent.setText("Sim. O Brasil tem uma boa tradição de bancos de leite, e há vários deles espalhados pelo território, muitas vezes dentro das próprias maternidades. Algumas cidades fazem parceria com o Corpo de Bombeiros, para que o leite ordenhado seja recolhido na casa das doadoras.\n" +
                            "\n" +
                            "O leite doado vai para o banco de leite, onde passa por um processo de pasteurização e é destinado a bebês prematuros ou que estejam internados em centros de tratamento intensivo neonatal. \n" +
                            "\n" +
                            "O primeiro passo é entrar em contato com o banco de leite humano mais próximo por telefone. Além de fazer o cadastro inicial, você será orientada sobre como fazer a coleta e armazenar o leite ordenhado. \n" +
                            "\n" +
                            "O banco de leite faz um cadastro, contendo dados pessoais, sobre o pré-natal e sobre os hábitos de vida da doadora. As informações são avaliadas por um médico e a doadora apta é avisada pelo banco de leite sobre o dia da coleta.");
                    break;
                default:
            }
        }
    }

    public void buttonBack(View view) {
        onBackPressed();
    }
}
