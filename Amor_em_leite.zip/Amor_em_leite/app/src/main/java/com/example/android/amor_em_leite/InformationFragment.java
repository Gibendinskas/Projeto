package com.example.android.amor_em_leite;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class InformationFragment extends Fragment {

    private Intent intent;
    private CardView cardViewComoDoar, cardViewPossoDoar, cardViewRestricoes, cardViewFaltar, cardViewBanco, cardViewImportancia,cardViewTratamento;


    public static InformationFragment newInstance() {
        InformationFragment fragment = new InformationFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        intent = new Intent(getContext(), CardInformationActivity.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_information, container, false);

        cardViewComoDoar = (CardView) view.findViewById(R.id.card_como_doar);
        cardViewImportancia = (CardView) view.findViewById(R.id.card_importancia);
        cardViewRestricoes = (CardView) view.findViewById(R.id.card_restricoes);
        cardViewPossoDoar = (CardView) view.findViewById(R.id.card_posso_doar);
        cardViewFaltar = (CardView) view.findViewById(R.id.card_faltar);
        cardViewBanco = (CardView) view.findViewById(R.id.card_banco);
        cardViewTratamento = (CardView) view.findViewById(R.id.card_tratamento);

        cardViewComoDoar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 0);
                startActivity(intent);
            }
        });

        cardViewFaltar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 1);
                startActivity(intent);
            }
        });

        cardViewBanco.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 2);
                startActivity(intent);
            }
        });

        cardViewTratamento.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 3);
                startActivity(intent);
            }
        });

        cardViewImportancia.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 4);
                startActivity(intent);
            }
        });

        cardViewRestricoes.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 5);
                startActivity(intent);
            }
        });

        cardViewPossoDoar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 6);
                startActivity(intent);
            }
        });

        return view;
    }
}
