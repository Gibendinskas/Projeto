package com.example.android.amor_em_leite;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class FeedFragment extends Fragment {

    private Intent intent;

    LinearLayout linearLayout1;
    LinearLayout linearLayout2;
    LinearLayout linearLayout3;
    LinearLayout linearLayout4;

    public static FeedFragment newInstance() {
        FeedFragment fragment = new FeedFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        intent = new Intent(getContext(), ProfileActivity.class);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_feed, container, false);

        linearLayout1 = (LinearLayout) view.findViewById(R.id.linear_layout_1);
        linearLayout2 = (LinearLayout) view.findViewById(R.id.linear_layout_2);
        linearLayout3 = (LinearLayout) view.findViewById(R.id.linear_layout_3);
        linearLayout4 = (LinearLayout) view.findViewById(R.id.linear_layout_4);

        linearLayout1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 0);
                startActivity(intent);
            }
        });

        linearLayout2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 1);
                startActivity(intent);
            }
        });

        linearLayout3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 2);
                startActivity(intent);
            }
        });

        linearLayout4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                intent.putExtra("position", 3);
                startActivity(intent);
            }
        });

        return view;
    }
}
