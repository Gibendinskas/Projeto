package com.example.android.amor_em_leite;

import android.app.Activity;

/**
 * Created by HP on 23/09/2018.
 */

public class TelaInicial extends Activity {

}
