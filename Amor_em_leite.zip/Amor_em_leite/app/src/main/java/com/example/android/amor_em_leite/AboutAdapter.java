package com.example.android.amor_em_leite;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class AboutAdapter extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;

    public AboutAdapter(Context context){
        this.context = context;
    }

    //lista de imagens
    public int[] slide_images = {
            R.drawable.breast_pump,
            R.drawable.icon2,
            R.drawable.icon3,
    };

    //lista de títulos
    public String[] slide_titulos = {
            "DOE LEITE, SALVE VIDAS",
            "O BLH MAIS PRÓXIMO A VOCÊ",
            "O GESTO QUE ALIMENTA"
    };

    //lista de textos
    public String[] slide_textos = {
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
    };

    //lista de cores dos textos
    public int[] lst_textcolor = {
            Color.rgb(255,255,255),
            Color.rgb(255,255,255),
            Color.rgb(255,255,255)
    };

    //lista de backgrounds
    public int[] lst_backgroundcolor = {
            Color.rgb(255,247,128),
            Color.rgb(255,245,97),
            Color.rgb(255,250,130)
    };


    @Override
    public int getCount() {
        return slide_titulos.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == (RelativeLayout) o;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.about_layout, container, false);

        ImageView slideImageView = (ImageView) view.findViewById(R.id.slide_image);
        TextView slideTitulos = (TextView) view.findViewById(R.id.slide_titulo);
        TextView slideTextos = (TextView) view.findViewById(R.id.slide_texto);

        slideImageView.setImageResource(slide_images[position]);
        slideTitulos.setText(slide_titulos[position]);
        slideTextos.setText(slide_textos[position]);
        slideTitulos.setTextColor(lst_textcolor[position]);
        slideTextos.setTextColor(lst_textcolor[position]);

        container.addView(view);

        return view;

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {

        container.removeView((RelativeLayout)object);

    }
}
