package com.example.android.amor_em_leite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    private int position;

    private TextView textViewPhone, textViewEmail, textViewAbout, textViewLocation, textViewTitle, textViewTitleExtended;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        textViewPhone = findViewById(R.id.phone_text);
        textViewEmail = findViewById(R.id.email_text);
        textViewAbout = findViewById(R.id.content_text);
        textViewLocation = findViewById(R.id.location_text);
        textViewTitle = findViewById(R.id.title_text);
        textViewTitleExtended = findViewById(R.id.title_extendend_text);

        if (getIntent().hasExtra("position")) {

            position = getIntent().getIntExtra("position", 0);

            switch (position) {
                case 0:
                    textViewTitle.setText("BLH");
                    textViewTitleExtended.setText("Hospital Mun. Universitário de São Bernardo do Campo");
                    textViewAbout.setText("Nossa missão é a promoção da saúde da mulher e da criança, sendo o apoio à amamentação e à mobilização pela doação de leite humano fundamentais nesse processo");
                    textViewLocation.setText("Avenida Bispo César D`Arcoso Filho, 161 Rudge Ramos - SP ");
                    textViewEmail.setText("blhsbc@gmail.com");
                    textViewPhone.setText("11-4365-1480 ");
                    break;

                case 1:
                    textViewTitle.setText("BLH -");
                    textViewTitleExtended.setText("Banco de Leite Humano do Hospital e Maternidade Santa Joana");
                    textViewAbout.setText("Nossa missão é a promoção da saúde da mulher e da criança, sendo o apoio à amamentação e à mobilização pela doação de leite humano fundamentais nesse processo");
                    textViewLocation.setText("Rua Dr. Eduardo Amaro, 157 Paraíso - SP ");
                    textViewEmail.setText("santajoanablh@gmail.com");
                    textViewPhone.setText("11-5080-6062 ");
                    break;

                case 2:
                    textViewTitle.setText("BLH -");
                    textViewTitleExtended.setText("Banco de Leite Humano do Hospital Geral Vila Penteado ");
                    textViewAbout.setText("Nossa missão é a promoção da saúde da mulher e da criança, sendo o apoio à amamentação e à mobilização pela doação de leite humano fundamentais nesse processo");
                    textViewLocation.setText("Avenida Ministro Petrônio Portela, 1.642 Freguesia do Ó - SP ");
                    textViewEmail.setText("vilapenteadohbl@gmail.com");
                    textViewPhone.setText("11-3976-9911 ");
                    break;

                case 3:
                    textViewTitle.setText("BLH -");
                    textViewTitleExtended.setText("Banco de Leite Humano do Hospital Ipiranga");
                    textViewAbout.setText("Nossa missão é a promoção da saúde da mulher e da criança, sendo o apoio à amamentação e à mobilização pela doação de leite humano fundamentais nesse processo");
                    textViewLocation.setText("Avenida Nazaré, 28 Ipiranga - SP");
                    textViewEmail.setText("ipirangablh@gmail.com");
                    textViewPhone.setText("11-2067-7866 ");
                    break;
                default:

            }
        }
    }

    public void buttonBackMain(View view) {
        onBackPressed();
    }
}